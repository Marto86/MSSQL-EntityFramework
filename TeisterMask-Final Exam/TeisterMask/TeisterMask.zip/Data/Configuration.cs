﻿namespace TeisterMask.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=TeisterMask;Trusted_Connection=True";
    }
}
